//Sponshorship  Replacements


// line 60 <p> id ="sponsorblurb1"
// line 62 <img> id = "sponsormainimg"

//line 69 <h1> id = "sponsortitle"
//line 70 <p> id = "sponsorblurb 2"

//events tab view
// line 114 <div h7> id = "sponsorEvent1"
// line 117 <div h7> id = "sponsorEvent2"
// line 120 <div h7> id = "sponsorEvent3"
// line 123 <div h7> id = "sponsorEvent4"
// line 126 <div h7> id = "sponsorEvent5"
// line 129 <div h7> id = "sponsorEvent6"

// line 135 <h2 light> id = "sponsorEventTitle1"
// line 136 <h4 light> id = "sponsorEventDate1"
// line 137 <p> id = "sponsorEventText1"

// times 6

//Sponsor Types
//line 186 <h2> id = "sponsorTypeTitle"
//line 187 <p> id = "sponsorTypeText"

//line 194 <p> id = "sponsorType1"
//line 195 <p> id = "sponsorTypeBlurb1"

//line 194 <p> id = "sponsorType2"
//line 195 <p> id = "sponsorTypeBlurb2"

//line 194 <p> id = "sponsorType3"
//line 195 <p> id = "sponsorTypeBlurb3"

//line 194 <p> id = "sponsorType4"
//line 195 <p> id = "sponsorTypeBlurb4"


//Sponsor tiers
//line 220 <h2> id = "sponsorTierTitle"
//line 224 <h5> id = "tierLevel1"
//line 225 <h1> id = "tierPrice1"
//line 227 <h5> id = "tierShowDay1"
//line 229 <div> id = "tierInprint1"
//line 231 <div> id = "tierMedia1"
//line 232 <h5> id = "tierPerks1"

//times 4

//Donate
//line 307 <a> id = "donateLink"

//Get in touch
//line 315 <p> id = "getInTouch"
//line 315 <a> id = "emailSponsorship"

//sponsor list
//large section
//line 321 <div> sponsor gallery id = "sponsorGallery1"
//Mid section
//line 357 <div> sponsor gallery id = "sponsorGallery2"
//Mid section
//line 390 <div> sponsor gallery id = "sponsorGallery3"

// //<!-- Linking Contentful Library-->
// <script src="https://cdn.jsdelivr.net/npm/contentful@latest/dist/contentful.browser.min.js"></script>
//<script src= "/js/contentful.js"></script>
//<script src= "/js/sponsorpagecontent.js"></script>

//Update Large Sponsor Section

//batch create array var and load url links and sponsor name in the slots
// var charityPicsURl =['../images/school.jpg', '../images/school-kids.jpg','../images/sponsorship-img-03.jpg','../images/school-girl.png'];
//
// var backgroundimgs ='';
// var currentSelection = '';
//
// for (var i = 0; i < charityPicsURl.length; i++) {
// var backgroundimgs = 'url(' + charityPicsURl[i] + ')';
// currentSelection = 'charIMG'+ [i+1];
// document.getElementById(currentSelection).style.backgroundImage = backgroundimgs;
// }

//Large Sponsor Logos
var largeSponsorName = ['Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students', 'Federation of Students'] ;
var largeSponsorLogo = ['images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png', 'images/feds-logo.png'] ;

var largeSponsorSection = '';

for (var i = 0; i < largeSponsorName.length; i++){
largeSponsorSection += '<div class="sponsor-div"><img src="'+ largeSponsorLogo[i] + '" class="sponsors-logo"> <div class="paragraph sponsor large">' + largeSponsorName[i] + '</div> </div>'
}

document.getElementById('sponsorGallery1').innerHTML = largeSponsorSection;

//Mid Sponsor Logos
var medSponsorName = ['GAP – Conestoga Mall', 'Bench. – Conestoga Mall', 'Hudson&#x27;s Bay – Fairview Mall'] ;
var medSponsorLogo = ['images/gap-logo.png', 'images/bench-logo.svg', 'images/Hudsons_Bay_logo.png'] ;

var medSponsorSection = '';

for (var i = 0; i < medSponsorName.length; i++){
medSponsorSection += '<div class="sponsor-div med"><img src="'+ medSponsorLogo[i] + '" class="sponsors-logo"> <div class="paragraph sponsor small">' + medSponsorName[i] + '</div> </div>'
}

document.getElementById('sponsorGallery2').innerHTML = medSponsorSection;

//small Sponsor Logos
var smlSponsorName = ['GAP – Conestoga Mall', 'Bench. – Conestoga Mall', 'Hudson&#x27;s Bay – Fairview Mall'] ;
var smlSponsorLogo = ['images/gap-logo.png', 'images/bench-logo.svg', 'images/Hudsons_Bay_logo.png'] ;

var smlSponsorSection = '';

for (var i = 0; i < medSponsorName.length; i++){
smlSponsorSection += '<div class="sponsor-div small"><img src="'+ smlSponsorLogo[i] + '" class="sponsors-logo"> <div class="paragraph sponsor small">' + smlSponsorName[i] + '</div> </div>'
}

document.getElementById('sponsorGallery3').innerHTML = smlSponsorSection;
