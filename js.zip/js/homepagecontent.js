//Home Page Text Replacements

//line 92 <P> id = "charityPartner"
//line 99 <h1> id = "donateAmntTitle"
// line 101 <p> id = "donateAmntText"
//line 134 <div> id = "copyrightDay"
//<script src= "/js/contentful.js"></script>
//<script src= "/js/homepagecontent.js"></script>


//Banner

var bannerTitleText = 'I need to see how long this can go for till it goes to the next line';
var bannerCTA = 'Buy FC Merch';
var bannerCTAlink = 'http://fcstore.ca/';

//formarting it to fit in url
var bannerImageURL = "../images/Copy-of-IMG_7725-p-1080.jpeg";
// var bannerImage = "url('../images/about-us-page-p-1080.png')";
var bannerImage = 'url(' + bannerImageURL + ')';

// Replace Banner Title Text
document.getElementById('bannerTitle').textContent = bannerTitleText;

// Replace Banner Button and Link
document.getElementById('bannerCTA').textContent = bannerCTA;
document.getElementById('bannerCTA').href= bannerCTAlink;
document.getElementById('bannerImageID').style.backgroundImage= bannerImage;



//Video//
var youtubeVideoCode = 'RPbQhwiufts';
var embedCodeLink = 'https://www.youtube.com/embed/' + youtubeVideoCode + '?autoplay=1&disablekb=1&loop=1&modestbranding=1&rel=0&mute=1';


document.getElementById('autoVideo').src = embedCodeLink;


// Charity partner//
var charityBlurb = "For the past 22 years we have donated all our proceeds to rebuild the community in Moyamba, Sierra Leone. Through WE’s Adopt A Village Campaign we’ve helped improve schooling for the children of Moyamba.";

document.getElementById('charityPartner').textContent = charityBlurb;


//Amount update//

var newAmount = '$140,000';

document.getElementById('donateAmntTitle').textContent = newAmount + ' and counting.';

document.getElementById('donateAmntText').innerHTML = 'Fashion for Change has raised ' + newAmount + ' for the village of Moyamba, Sierra Leone. We are only able to do this through the dedicated students and supportive community! Learn how <a href="https://www.crowdrise.com/o/en/campaign/fashion-for-change-2017-2018" target="_blank" class="in-text-link">can give directly</a>, <a href="sponsorship.html" class="in-text-link">sponsor our initiatives</a>, or <a href="http://fashionforchange.ca/teams#join-team" class="in-text-link">join the club</a>.<br>';

//footer copyright message year
var today = new Date();
var currentYear = today.getFullYear();

document.getElementById('copyrightDay').textContent = '©Fashion for Change ' + currentYear;
