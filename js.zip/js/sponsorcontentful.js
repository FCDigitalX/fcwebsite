//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.
var sponsorPageID = '5pb1Ygrih2IAkc6qyG2IOw';
var teamPageID = 'ZVRfRjjU8SwcKWiCGkwwS';


//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})


//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];

// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      //console.log(allContentfullEntries)

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry is a sponsorpage by searching for sponsorPageID
        if(allContentfullEntries[i].sys.id == sponsorPageID){

          console.log(allContentfullEntries[i].fields)

          renderSponsorMainTitleSection(allContentfullEntries[i].fields.sponsorshipTitle, allContentfullEntries[i].fields.sponsorMainImage.fields.file.url, allContentfullEntries[i].fields.sponsorshipPageBlurb)

          renderSponsorTitleSection(allContentfullEntries[i].fields.sponsorshipPackageTitle, allContentfullEntries[i].fields.sponsorshipPackageText)

          renderSponsorEventsSlider(allContentfullEntries[i].fields.annualEventsTab)

          renderSponsorTypes(allContentfullEntries[i].fields.sponsorTypeSection, allContentfullEntries[i].fields.sponsorshipTypesSectionText, allContentfullEntries[i].fields.sponsorshipTypesSectionTitle)

          renderSponsorTiers(allContentfullEntries[i].fields.monetarySponsorTiers)

          renderDonateSection(allContentfullEntries[i].fields.donateSectionTitle , allContentfullEntries[i].fields.donateSectionText, allContentfullEntries[i].fields.donateSectionLink)

          renderGetInTouchSection(allContentfullEntries[i].fields.getInTouchTitle, allContentfullEntries[i].fields.getInTouchText, allContentfullEntries[i].fields.getInTouchEmail)

          renderMainSponsorLogos(allContentfullEntries[i].fields.mainSponsorLogos)

          renderHairMakeupSponsorLogos(allContentfullEntries[i].fields.hairMakeupSponsorLogos)

          renderinKindSponsorLogos(allContentfullEntries[i].fields.inKindSponsorLogos)



        }
      }

    })



function renderSponsorMainTitleSection(sponsorshipTitle, sponsorMainImage, sponsorshipPageBlurb){

  var sponsorshipMainBlurb = '<div class="blue-text-block"></div><h1 class="h1 black left">' + sponsorshipTitle + '</h1><p class="paragraph">' + sponsorshipPageBlurb + '<br></p>'

  var sponsorImage = '<img src="' + sponsorMainImage + '">'

  document.getElementById('sponsorBlurb1').innerHTML = sponsorshipMainBlurb;
  document.getElementById('sponsorMainImg').innerHTML = sponsorImage;

  }

function renderSponsorTitleSection(sponsorshipPackageTitle, sponsorshipPackageText){

var sponsorshipTitleArea = '<h1 class="h1 black centre">' + sponsorshipPackageTitle + '</h1><p class="paragraph centre">' + sponsorshipPackageText + '</p>';


document.getElementById('sponsorTitle').innerHTML = sponsorshipTitleArea;

}



function renderSponsorEventsSlider(annualEventsTabs){

  var tabs = [];
  tabs = annualEventsTabs;
  var tabTitles ='';
  var tabContent = '';
  //console.log(types)

  for(var i = 0; i < tabs.length; i++){

//orginal tab items change
    document.getElementById('sponsorEventTitle1').innerHTML = '<div  class="h7">' + tabs[0].fields.eventTitle + '</div>'

    document.getElementById('sponsorEventTitle2').innerHTML = '<div  class="h7">' + tabs[1].fields.eventTitle + '</div>'

    document.getElementById('sponsorEvent1').innerHTML = '<h1 class="h2 light"> ' + tabs[0].fields.eventTitle + '</h1><h1 class="h4 light">' + tabs[0].fields.dateOfEvent + '</h1><p class="paragraph small light">' + tabs[0].fields.eventDescription +'</p>'

    document.getElementById('sponsorEvent2').innerHTML = '<h1 class="h2 light"> ' + tabs[1].fields.eventTitle + '</h1><h1 class="h4 light">' + tabs[1].fields.dateOfEvent + '</h1><p class="paragraph small light">' + tabs[1].fields.eventDescription +'</p>'

    var cssstuff = 'linear-gradient(90deg, rgba(8, 31, 51, .83), hsla(0, 0%, 100%, 0)), url(' + tabs[0].fields.eventPicture.fields.file.url +')'

    document.getElementById('sponsorEvent1').style.backgroundImage = cssstuff

    var cssstuff2 = 'linear-gradient(90deg, rgba(8, 31, 51, .83), hsla(0, 0%, 100%, 0)), url(' + tabs[1].fields.eventPicture.fields.file.url +')'

    document.getElementById('sponsorEvent2').style.backgroundImage = cssstuff2

if (i > 1){
    if (tabs[i].fields.eventTitle  != undefined || tabs[i].fields.eventTitle  != null){

      function myFunction(x) {
    if (x.matches) { // If media query matches
        document.body.style.backgroundColor = "yellow";
    } else {
        document.body.style.backgroundColor = "pink";
    }
}


      //CSS and picture changing
      var tabPic = 'background-image: linear-gradient(90deg, rgba(8, 31, 51, .83), hsla(0, 0%, 100%, 0)), url(' + tabs[i].fields.eventPicture.fields.file.url +'); background-position: 0px 0px, 50% 50%; background-size: auto, cover;background-repeat: repeat, no-repeat;'

      //setting the tab title
      var titleTabs = '<a data-w-tab="' + tabs[i].fields.eventTitle + '" class="sponsorship-event-tab w-inline-block w-tab-link"> <div class="h7">' + tabs[i].fields.eventTitle  + '</div> </a>'

      //appending new tab ttitle to list
      document.getElementById('sponsorEventTitle').insertAdjacentHTML('beforeend', titleTabs )

      //setting the tab content
      var titleContent = '<div data-w-tab="' + tabs[i].fields.eventTitle + '" class="event-div w-tab-pane"> <div class="event-spon-bg" style = "' + tabPic +'"> <h1 class="h2 light">' + tabs[i].fields.eventTitle + '</h1> <h1 class="h4 light">' + tabs[i].fields.dateOfEvent + '</h1> <p class="paragraph small light" >' + tabs[i].fields.eventDescription + '</p> </div> </div>'

      //appending tab content couresel
      document.getElementById('sponsorEvent').insertAdjacentHTML('beforeend', titleContent)


    }

}



// .backgroundImage
  // background-image: -webkit-linear-gradient(0deg, rgba(96, 176, 244, .9), hsla(0, 0%, 100%, 0)), url('../images/theme-release.jpg');
  // background-image: linear-gradient(90deg, rgba(96, 176, 244, .9), hsla(0, 0%, 100%, 0)), url('../images/theme-release.jpg');

  }

// document.getElementById('sponsorEventTitle').insertAdjacentHTML('beforeend', '<a data-w-tab="Pop-up shop" class="sponsorship-event-tab w-inline-block w-tab-link"><div class="h7">Merchandise Pop-Up Shop<br></div></a>')
//
// document.getElementById('sponsorEvent').insertAdjacentHTML('beforeend', '<div data-w-tab="Pop-up shop" class="w-tab-pane"><div class="event-spon-bg merch"><h1 class="h2 light">Merchandise Pop-Up Shop</h1><h1 class="h4 light">April 2019</h1><p class="paragraph small light">Training session for 80+ models and dancers in show.<br>Two 8 hour days of learning and exercise.<br>Opportunity to serve sponsored food and refreshments.</p></div></div>')

}


function renderSponsorTypes(sponsorTypes, sponsorTypeText, sponsorTypeTitle) {

  var types = [];
  types = sponsorTypes;
  //console.log(types)
  var sponsorTypesSection = '';
  var sponsorTypesTextPart ='';

  sponsorTypesTextPart += '<h2 class="h2 centre">2. ' + sponsorTypeTitle + '</h2><p class="paragraph centre">' + sponsorTypeText + '</p>'

  for(var i = 0; i < types.length; i++){

    var num = i+1;

    sponsorTypesSection += '<a  href="#packages" class="sponsorship-item-link w-inline-block"> <div class="sponsorship-package _' + num + '"><h5 class="label">' + types[i].fields.sponsorshipType + '</h5><p class="paragraph small">' + types[i].fields.sponsorTypeBlurb + '</p></div></a>'
  }

  document.getElementById('sponsorTypesText').innerHTML = sponsorTypesTextPart;
  document.getElementById('sponsorTypes').innerHTML = sponsorTypesSection;

}

function renderSponsorTiers(sponsorTiers){

  var tier = [];
  tier = sponsorTiers;
  //console.log(tiers)
  var sponsorTierSection = '';

  for(var i = 0; i < tier.length; i++){

    sponsorTierSection += '<div class="sponsorship-tier ' + tier[i].fields.tierColour + '"><h5 class="label">' + tier[i].fields.tierLevel + '</h5><h1 class="price ' + tier[i].fields.tierColour + '">' + tier[i].fields.tierPrice + '</h1>'

    sponsorTierSection += '<h5 class="top-label">' + tier[i].fields.offeringSection1Title + '</h5><div class="paragraph small list">'+ tier[i].fields.offeringSection1 +'</div>'

    sponsorTierSection += '<h5 class="top-label">' + tier[i].fields.offeringSection2Title + '</h5><div class="paragraph small list">'+ tier[i].fields.offeringSection2 +'</div>'

    sponsorTierSection += '<h5 class="top-label">' + tier[i].fields.offeringSection3Title + '</h5><div class="paragraph small list">'+ tier[i].fields.offeringSection3 +'</div>'

    sponsorTierSection += '<h5 class="top-label">' + tier[i].fields.offeringSection4Title + '</h5><div class="paragraph small list">'+ tier[i].fields.offeringSection4 +'</div>'

    //check if it has offering section 1 2 or 3 or 4 ro 5
    if (tier[i].fields.offeringSection5Title  != undefined || tier[i].fields.offeringSection5Title  != null){

      sponsorTierSection += '<h5 class="top-label">' + tier[i].fields.offeringSection5Title + '</h5>'
    }

    if (tier[i].fields.offeringSection5 != undefined || tier[i].fields.offeringSection5  != null){

      sponsorTierSection += '<div class="paragraph small list">'+ tier[i].fields.offeringSection5 +'</div>'
    }

    sponsorTierSection += ' </div>'

  }

//inject all html in the main logo section but using the div id.
  document.getElementById('sponsorTiers').innerHTML = sponsorTierSection;

}

//Donate section text and title
function renderDonateSection(title, text, link) {

  var donateSection ='';
  var donateSectionText = text;
  var donateSectionLink = link;
  var donateSectionTitle = title;

  donateSection += '<div class="section-div-text right donate w-clearfix"> <h2 class="h2 centre">4.' + donateSectionTitle + '</h2> <p class="paragraph donate">' + donateSectionText +'</p><a href="' + donateSectionLink + '" target="_blank" class="button dark round orange w-button">Give Directly</a></div> <div class="section-div-img"><img src="images/school-kids.jpg" srcset="images/school-kids-p-500.jpeg 500w, images/school-kids-p-800.jpeg 800w, images/school-kids-p-1080.jpeg 1080w, images/school-kids.jpg 1116w" sizes="100vw"></div>'

document.getElementById('donateSection').innerHTML = donateSection;

}

//Replacing info in getin Touch section
function renderGetInTouchSection(title, text, email){

      var gitSection ='';
      var getInTouchText = text;
      var getInTouchEmail = email;
      var getInTouchTitle = title;



      gitSection += '<h1 class="h1 black centre">'+ getInTouchTitle + '</h1> <p class="paragraph centre">' + getInTouchText + '<br></p><a href="mailto:' + getInTouchEmail + '?subject=Sponsoring Fashion for Change" class="button dark round w-button">Email us</a>'

   document.getElementById('getInTouch').innerHTML = gitSection;

  }



//Replace Large Sponsor Logo
function renderMainSponsorLogos(logos){

  var mainLogos = [];
  mainLogos = logos;
  //console.log(mainLogos)
  var largeSponsorSection = '';

  for(var i = 0; i < mainLogos.length; i++){
    // console.log(mainLogos[i].fields.title)
    // console.log(mainLogos[i].fields.file.url)

// cycle through logos in mainLogos array and create HTML script to replace the main logo section
    largeSponsorSection += '<div class="sponsor-div"><img src="'+ mainLogos[i].fields.file.url + '" class="sponsors-logo"> <div class="paragraph sponsor large w-hidden-tiny">' + mainLogos[i].fields.title + '</div> </div>'
  }
//inject all html in the main logo section but using the div id.
  document.getElementById('sponsorGallery1').innerHTML = largeSponsorSection;

}

//Replace Medium  Sponsor Logo
function renderHairMakeupSponsorLogos(logos){

  var medLogos = [];
  medLogos = logos;
  //console.log(mainLogos)
  var medSponsorSection = '';

  for(var i = 0; i < medLogos.length; i++){
    // console.log(mainLogos[i].fields.title)
    // console.log(mainLogos[i].fields.file.url)

// cycle through logos in medLogos array and create HTML script to replace the med logo section
    medSponsorSection += '<div class="sponsor-div med"><img src="'+ medLogos[i].fields.file.url + '" class="sponsors-logo"> <div class="paragraph sponsor small w-hidden-tiny">' + medLogos[i].fields.title + '</div> </div>'
  }
//inject all html in the main logo section but using the div id.
  document.getElementById('sponsorGallery2').innerHTML = medSponsorSection;

}

//Replace Small Sponsor Logo
function renderinKindSponsorLogos(logos){

  var smlLogos = [];
  smlLogos = logos;
  //console.log(smlLogos)
  var smlSponsorSection = '';

  for(var i = 0; i < smlLogos.length; i++){
    // console.log(mainLogos[i].fields.title)
    // console.log(mainLogos[i].fields.file.url)

// cycle through logos in medLogos array and create HTML script to replace the med logo section
    smlSponsorSection += '<div class="sponsor-div small"><img src="'+ smlLogos[i].fields.file.url + '" class="sponsors-logo"> <div class="paragraph sponsor small w-hidden-tiny">' + smlLogos[i].fields.title + '</div> </div>'
  }
//inject all html in the main logo section but using the div id.
  document.getElementById('sponsorGallery3').innerHTML = smlSponsorSection;

 }

 //footer copyright message year
 var today = new Date();
 var currentYear = today.getFullYear();

 document.getElementById('copyrightDay').textContent = '©Fashion for Change ' + currentYear;
