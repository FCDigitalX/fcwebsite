//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34

var teamPageID = 'ZVRfRjjU8SwcKWiCGkwwS'

//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})


//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];


// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      // console.log(allContentfullEntries)

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry is a sponsorpage by searching for sponsorPageID
        if(allContentfullEntries[i].sys.id == teamPageID){

          console.log(allContentfullEntries[i].fields)



          renderTitleSection(allContentfullEntries[i].fields.meetTheTeamTitle, allContentfullEntries[i].fields.meetTheTeamText)


          renderPresidentSection(allContentfullEntries[i].fields.messageFromPresidentTitle, allContentfullEntries[i].fields.presidentMessage, allContentfullEntries[i].fields.presidentName, allContentfullEntries[i].fields.presidentsPicture.fields.file.url)

          renderDirectorsSection(allContentfullEntries[i].fields.currentDirectors)

          renderJoinTeam(allContentfullEntries[i].fields.joinOurTeamText, allContentfullEntries[i].fields.joinOurTeamPicture.fields.file.url)

          renderStepstoJoin(allContentfullEntries[i].fields.step1text, allContentfullEntries[i].fields.step2text, allContentfullEntries[i].fields.step3text)




        }
      }

    })


function renderTitleSection(meetTheTeamTitle, meetTheTeamText){

  var meetTeamSection = '<h1 class="h1 black centre">' + meetTheTeamTitle + '</h1><p class="paragraph centre">' + meetTheTeamText + '<br></p>'

  document.getElementById('meetTeamTitle').innerHTML = meetTeamSection;


}


function renderPresidentSection(messageFromPresidentTitle, presidentMessage, presidentName, presidentsPicture){


var presidentSection = '<div class="section-div president"><div class="section-div-img president"><div class="w-dyn-list"><div class="w-dyn-items"><div class="w-dyn-item"><img src="' + presidentsPicture + '" sizes="(max-width: 479px) 90vw, (max-width: 767px) 56vw, (max-width: 991px) 284.796875px, 100vw" class="team-member-img pres"></div></div></div></div><div class="section-div-text right team"><h1 class="h2">' + messageFromPresidentTitle + '</h1><p class="paragraph small president">' + presidentMessage + '</p><div class="h5">' + presidentName + '</div><div class="h6">President</div></div></div>'

document.getElementById('presidentSec').innerHTML = presidentSection;

  }


  function renderDirectorsSection(directorObject){

      var directors = [];
      directors = directorObject;
      //console.log(types)
      var directorSection = '';


      for(var i = 0; i < directors.length; i++){

        var num = i+1;

        directorSection += '<div class="team-gallery-item w-dyn-item"><div style="background-image:url(' + directors[i].fields.directorPicture.fields.file.url + ')" class="team-member-img"></div><div class="gallery-info-div"><div class="title-block"><div class="h5">' + directors[i].fields.nameOfDirector + ' </div><div class="h6">' + directors[i].fields.directorPosition + '</div></div><div class="social-icons"><a href="' + directors[i].fields.linkedinUrl + '" class="fa-icon brand"></a></div></div></div>'
      }
      document.getElementById('directors').innerHTML = directorSection;

    }

function renderJoinTeam(joinOurTeamText, joinOurTeamPicture ){


  document.getElementById('joinText').textContent = joinOurTeamText;
  document.getElementById('joinsrc').src = joinOurTeamPicture;


}


function renderStepstoJoin(step1text, step2text, step3text){


  document.getElementById('step1').innerHTML = step1text;

  document.getElementById('step2').innerHTML= step2text;

  document.getElementById('step3').innerHTML = step3text;

}
