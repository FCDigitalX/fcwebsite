//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34
console.log("this js is working")

var homePageID ='3vEUiIJEggam0s8uwGqAmE'

//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'

})



//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];

// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)
      
 console.log("this js is working 2")
      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      console.log(allContentfullEntries)

      for(var i = 0; i < allContentfullEntries.length; i++){

        if(allContentfullEntries[i].sys.id == homePageID){

          console.log("this js is working 3")
          console.log(allContentfullEntries[i].fields)



          renderBanner(allContentfullEntries[i].fields.homepageBanner)

          renderBlock1(allContentfullEntries[i].fields.block1Text, allContentfullEntries[i].fields.block1Title)

          renderYoutube(allContentfullEntries[i].fields.fcPromoVideoUrl)

          renderBlock2(allContentfullEntries[i].fields.block2Text, allContentfullEntries[i].fields.block2Title, allContentfullEntries[i].fields.block2Image.fields.file.url)

          renderBlock3(allContentfullEntries[i].fields.block3Text, allContentfullEntries[i].fields.block3Title, allContentfullEntries[i].fields.block3Image.fields.file.url)

          renderCharityText(allContentfullEntries[i].fields.donatedText, allContentfullEntries[i].fields.donatedTitle)


        }
      }

    })


function renderBanner(banners){

  var allBanners = [];
  allBanners = banners;
  console.log(allBanners)


//loading banners into sldier
  for(var i = 0; i < allBanners.length; i++){

    var bannum = i + 1;
    var banId = 'bannerAD'+ bannum

  var bannerCollect = '<div class="slider-div w-clearfix"><h1 class="h1 white centre">'+ allBanners[i].fields.bannerTitleText + '</h1><a href="'+ allBanners[i].fields.bannerCtaLink + '" class="button dark round w-button">' + allBanners[i].fields.bannerCtaText +'</a></div>'


console.log(banId);

  document.getElementById( banId ).innerHTML= bannerCollect;

   document.getElementById(banId).style.backgroundImage= 'url(' + allBanners[i].fields.homeBannerImageLarge.fields.file.url + ')';

  }




}

function renderBlock1(block1Text, block1Title){

  var content = '<div class="blue-text-block"></div><h1 class="h1 black left">' + block1Title + '</h1><p class="paragraph">' + block1Text + '</p>'

  document.getElementById('block1').innerHTML = content;

}

//Video//
function renderYoutube(videoUrl){

//console.log(videoUrl);

  // var frame = '<iframe width="100%" height="100%" src="'+ fcPromoVideoUrl +'" frameborder="0" allowfullscreen=""> </iframe>'
//
//   document.getElementById('autoVideo').src = fcPromoVideoUrl
//
//   //console.log(frame);
//
//
// console.log(embedCodeLink);

document.getElementById('autoVideo').src = videoUrl;

}


function renderBlock2(block2Text, block2Title, block2Image){

  var content = '<div class="blue-text-block"></div><h1 class="h1 black left">' + block2Title + '</h1><p class="paragraph">' + block2Text + '</p>'

  var imgContent = '<img src="' + block2Image + '"  sizes="100vw">'

  document.getElementById('block2').innerHTML = content;

  document.getElementById('block2Img').innerHTML = imgContent;

}


function renderBlock3(block3Text, block3Title, block3Image){

  var content = '<div class="blue-text-block"></div><h1 class="h1 black left">' + block3Title + '</h1><p class="paragraph">' + block3Text + '</p>'

  var imgContent = '<div class="we-charity-logo-div"><img src="images/free-the-children.png" class="we-charity-logo"></div><img src="' + block3Image + '"  sizes="100vw">'

  document.getElementById('block3').innerHTML = content;

  document.getElementById('block3Img').innerHTML = imgContent;

}




function renderCharityText(donatedText, donatedTitle){

var title = '<h1 class="h1 black left">' + donatedTitle +'</h1> <div class="blue-text-block"></div>';

document.getElementById('donateAmntText').innerHTML = title;

document.getElementById('donateAmntText').insertAdjacentHTML('beforeend', donatedText )


}
