//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34

var aboutPageID = '3A2wmS4arK6QYyGkWKwyK2'

//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})



//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];

// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      //console.log(allContentfullEntries)

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry is a sponsorpage by searching for sponsorPageID
        if(allContentfullEntries[i].sys.id == aboutPageID){

          console.log(allContentfullEntries[i].fields)


         renderIntro(allContentfullEntries[i].fields.aboutPageTitle, allContentfullEntries[i].fields.aboutPageBlurb)

         renderMission(allContentfullEntries[i].fields.missionStatement, allContentfullEntries[i].fields.valueBlurb1, allContentfullEntries[i].fields.valueBlurb2, allContentfullEntries[i].fields.valueBlurb3)

         renderCharity(allContentfullEntries[i].fields.charityBlurb, allContentfullEntries[i].fields.statistics, allContentfullEntries[i].fields.weCharityPdf.fields.file.url, allContentfullEntries[i].fields.charityPictures)


        }
      }

    })


function renderIntro(aboutPageTitle, aboutPageBlurb){


var elements = '<h1 class="h1 white centre">'+ aboutPageTitle + '</h1><p class="paragraph light centre aboutus-intro">'+ aboutPageBlurb + '</p>'


  document.getElementById('aboutIntro').innerHTML = elements;


}

function renderMission(missionStatement, valueBlurb1, valueBlurb2, valueBlurb3){


    document.getElementById('missionIntro').innerText = missionStatement;

    document.getElementById('valueOne').innerText = valueBlurb1;

    document.getElementById('valueTwo').innerText = valueBlurb2;

    document.getElementById('valueThree').innerText = valueBlurb3;


}


function renderCharity(charityBlurb, statistics, weCharityPdf, charityPictures){

document.getElementById('charitySection').innerHTML = '<h2 class="h2 centre white">Our Charity</h2><p class="paragraph light centre">'+ charityBlurb + '</p>'


var charPics = [];
charPics = charityPictures;
console.log(charPics)

var cpics =''


for(var i = 0; i < charPics.length; i++){

  var num = i + 1

  cpics +='<div style="background-image: url('+ charPics[i].fields.file.url +'); " class="div-img _'+ num +'"></div>'

}

  document.getElementById('moyambaPics').innerHTML = cpics;


document.getElementById('stats').innerHTML = '<h2 class="h2 we-charity-title">From students, <br>for students</h2><div class="text-div"><p class="paragraph fact">Fashion for Change has donated </p></div>' + statistics

document.getElementById('doc').href = weCharityPdf

}
