//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34
console.log('its workin?')
var pageID = '2THR2ibuX6wIKqsMq4MiAk'

//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})


//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];

// call contentful client to get entries. Use promise to capture promise results


client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      //console.log(allContentfullEntries)

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry is a sponsorpage by searching for sponsorPageID
        if(allContentfullEntries[i].sys.id == pageID){

          console.log(allContentfullEntries[i].fields)


          renderSeason(allContentfullEntries[i].fields.eventTitlePage, allContentfullEntries[i].fields.seasonList)


        }
      }

    })



function renderSeason(eventTitlePage, seasonList) {

  var title = '<div class="top-div"><h1 class="h1 black">'+ eventTitlePage +'</h1></div>'

  document.getElementById('title').innerHTML = title;

  var season = [];
  season = seasonList;
   //console.log(seasonList)

  var year =''

   for(var i = 0; i < season.length; i++){

  year += '<div    data-w-id="5a777747-077a-8e32-2539-ac81e5c536b8" style="background-image:url('+ season[i].fields.seasonBackgroundImage.fields.file.url+')" class="event-section-div w-dyn-item"><a href= "'+ season[i].fields.seasonLink
  +'" data-w-id="ba4d2e4b-5411-c36b-28be-54408e63b7ff" style="opacity:0" class="event-link w-inline-block"></a><div data-w-id="d5ad5809-34fc-a518-4ea5-3320504437f8" style="opacity:1" class="gradient"></div><div class="section-div centre events" style= "width: auto" ><div><a class="season-info-div" href= "'+ season[i].fields.seasonLink
  +'" style=" text-decoration-color: #60b0f4;"><h2 class="theme light" style=" text-decoration-color: #60b0f4">'+ season[i].fields.seasonShowname +'</h2> </a><div class="season-info-div"><h2 class="h2 light season" style="text-decoration: none">'+ season[i].fields.seasonEndYear + ' Season</h2><h2 class="h2 light" style="text-decoration: none">$'+ season[i].fields.seasonAmntDonate
 +'</h2></div></div></div></div>'

  }

//console.log(year)

document.getElementById('seasoned').insertAdjacentHTML('beforeend', year)

//document.getElementById("seasoned").innerHTML = year



}
