//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke



//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34


//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})


//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];


// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      allContentfullEntries = entries.toPlainObject().items

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry has the same tag as the date
        if(seasonId == allContentfullEntries[i].fields.endYear){


          console.log(allContentfullEntries[i])

          // if(seasonId == allContentfullEntries[i].fields.endYear){

          renderheader(allContentfullEntries[i].fields.nameOfYear, allContentfullEntries[i].fields.headerPicture.fields.file.url, allContentfullEntries[i].fields.experienceLink)


          renderRecap(allContentfullEntries[i].fields.yearBlurb, allContentfullEntries[i].fields.recapSection, allContentfullEntries[i].fields.showPlayListLink, allContentfullEntries[i].fields.recapWords, allContentfullEntries[i].fields.embedshowPlayListLink)




        }
      }

    })


//if id from current html document == the year on the title of the api list, then use that seanson lIST ENTRY.


function renderheader(nameOfYear, headerPicture, experienceLink){

  var yeartop = '<div data-w-id="e8bf5e7c-31dc-c588-5586-58484615c77e" style="" class="top-div w-clearfix"> <h1 class="h1 white shadow">' + nameOfYear + '</h1> <a href="'+ experienceLink + '" target="_blank" class="button dark round home w-button">Experience the show </a></div>';


  var cssyear = 'linear-gradient(180deg, rgba(0, 0, 0, .5), rgba(0, 0, 0, .5)), url(' + headerPicture +')'

  document.getElementById('yearTitle').style.backgroundImage = cssyear


  document.getElementById('yearTitle').innerHTML= yeartop

}

function renderRecap(yearBlurb, recapSection, showPlayListLink, recapWords, embedshowPlayListLink){

var blurb = '<div class="section regular season-info"><div data-w-id="710390b6-fbf6-66d5-8b09-0abf08316c72" class="section-div left"> <div class="section-div-text season-info"> <h1 class="h1 left"> ' + seasonId +' Season</h1> <p class="paragraph light large">'+ yearBlurb +'</p> </div> </div> </div>'


var lastSection = '<div class="section regular short black"><div data-w-id="05420cbc-60a7-eaf2-144e-0b7b53b2a491" class="section-div sides"><div class="section-div-text left smaller w-clearfix"><h1 class="h1 left">Recap</h1><p class="paragraph light">'+ recapWords + '</p><a href="'+ showPlayListLink+ '" class="button dark round w-button">Watch more videos</a></div><div class="section-div-img video"><div class="html-embed-video w-embed w-iframe"><iframe width="100%" height="100%" src="'+ embedshowPlayListLink +'" frameborder="0" allowfullscreen=""> </iframe></div></div></div><div class="blue-block right video w-hidden-medium w-hidden-small w-hidden-tiny"></div></div>'

var sectionRecaps = [];
sectionRecaps = recapSection;

console.log(sectionRecaps)

var yearRecap = ''
var eachPhoto =''
var videos = ''
var photos = ''
var combine = ''

for(var i = 0; i < sectionRecaps.length; i++){

  yearRecap = ''
  eachPhoto =''
  videos = ''
  photos = ''

var sectionGallery = [];
sectionGallery = sectionRecaps[i].fields.recapGallery
console.log(sectionGallery)

  for(var d = 0; d < sectionGallery.length; d++){

    eachPhoto += '<img src="'+ sectionGallery[d].fields.file.url +'" sizes="(max-width: 479px) 100vw, (max-width: 767px) 218px, 308px" class="event-gallery-img">'

    photos = '<div data-w-id="4142b622-62a0-e9fd-0ea0-600054ebac11" class="section-div"><a href="#" class="season-img-gallery w-hidden-tiny w-inline-block w-lightbox">'+ eachPhoto +'<script type="application/json" src="js/galleryTest.json" class="w-json"></script></a></div>'
  }


var sectionVideos = [];
sectionVideos = sectionRecaps[i].fields.recapVideos
console.log(sectionVideos)

var iFrames = ''

if (sectionRecaps[i].fields.recapVideos !== undefined){
  for(var a = 0; a < sectionVideos.length; a++){

  iFrames += '<div class="section-div-img video"><div class="html-embed-video w-embed w-iframe"><iframe width="100%" height="100%" src="'+ sectionVideos[a].fields.embedLink +'" frameborder="0" allowfullscreen=""> </iframe></div></div>'

    videos = '<div data-w-id="2debf4d8-6c21-70bc-755c-fade207e38e6" class="section-div videos">'+ iFrames +'</div>'
  }
}

yearRecap = '<div class="section regular black"><div data-w-id="9d1d43ad-1b7b-c957-7733-bbfdaeebca51" class="section-div left"><div class="section-div-text season-info"><h1 class="h1 left">'+ sectionRecaps[i].fields.recapTile + '</h1><p class="paragraph light large">'+ sectionRecaps[i].fields.recapBlurb +'</p></div></div> '

combine += yearRecap + videos + photos

}

document.getElementById('recapSections').innerHTML = blurb + combine + lastSection


}
