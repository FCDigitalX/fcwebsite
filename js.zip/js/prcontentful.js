//Fashion for Change 2018 CMS Javascript compiler
//Seyitan Oke


//to change content space the website samples from, find and the change the IDs for the page you need to source from, then change the corrseponsing variable in this document.

// you can change the  page ID on line 8,and 34

var BODPageID = '1soeYLli3W8YWCySUikku8'

//reciving contentful JSON file using Contentful Client
var client = contentful.createClient({
  accessToken: '7fe52d07a83eb741d68bb26dfe0d1c7d9496b24cd138d29f1d266856183c9c42',
  space: 'sotwyyty953a'
})


//Creacte variable to contain all contentfull Entries
var allContentfullEntries = [];

// call contentful client to get entries. Use promise to capture promise results
client.getEntries({
  limit: 1000
}).then(function (entries){
      console.log(entries)

      //turn contentful results to plau json object and put it in the allContentfullEntries variable
      allContentfullEntries = entries.toPlainObject().items

      //console.log(allContentfullEntries)

      //loop through the entries to find the pages lookign for
      for(var i = 0; i < allContentfullEntries.length; i++){

        //check if entry is a sponsorpage by searching for sponsorPageID
        if(allContentfullEntries[i].sys.id == BODPageID){

          console.log(allContentfullEntries[i].fields)


          renderTeamTitleSection(allContentfullEntries[i].fields.teamName,allContentfullEntries[i].fields.teamType, allContentfullEntries[i].fields.teamDescription, allContentfullEntries[i].fields.teamPicture)

          renderPositionsSection(allContentfullEntries[i].fields.teamPositions)

          renderProcessSection(allContentfullEntries[i].fields.teamApplicationProcess)

          renderFaqSection(allContentfullEntries[i].fields.teamFaq)

          renderEmail(allContentfullEntries[i].fields.teamDirectorEmail)


        }
      }

    })


function renderTeamTitleSection(teamName, teamType, teamDescription, teamPicture) {

  var teamInfo = '<div class="section-div-text left"><div class="team-colour-div '+ teamType + '"></div><h1 class="h1 black left"> '+ teamName + '</h1><p class="paragraph">'+ teamDescription + '<br></p></div><div class="section-div-img"><img src="' + teamPicture.fields.file.url + '" sizes="100vw"></div>'

  document.getElementById('teamTitleSec').innerHTML = teamInfo;


}


function renderProcessSection(teamApplicationProcess){

  var stepsList = [];
  stepsList = teamApplicationProcess;
  console.log(stepsList)

  var steps =''


  for(var i = 0; i < stepsList.length; i++){

  var numb = i + 1;

    steps += '<div class="app-process-div"><h1 class="step black">Step '+ numb +': ' + stepsList[i].fields.stepTitle + '</h1><div class="paragraph small">' + stepsList[i].fields.stepDescription + '</div></div>'

  }

  document.getElementById('application-stepsList').innerHTML = steps;

}



function renderFaqSection(teamFaq){

  var faqList = [];
  faqList  = teamFaq;
  console.log(faqList)

  var faq =''

  for(var i = 0; i < faqList.length; i++){

    faq += '<div class="faq"><h1 class="question">'+ faqList[i].fields.faqQuestion + '</h1><div class="paragraph small faq">'+ faqList[i].fields.faqAnswer + '</div></div>'

  }

  document.getElementById('listFaq').innerHTML = faq;

}

function renderEmail(teamDirectorEmail){

   document.getElementById('emailDirector').innerHTML ='<h1 class="h1 black centre">Have more questions?</h1><p class="paragraph centre">If you have any questions about this team, the application process. Make sure to join us at our annual information session or email us directly.<br></p> <a href="mailto:' + teamDirectorEmail + '?subject=Join Fashion for Change" class="button dark round w-button">Email us</a>'


}

function renderPositionsSection(teamPositions){

  var postings = [];
  postings = teamPositions;
  var tabTitles ='';
  var tabContent = '';
  console.log(postings)

  // .fields.applicationFormLink
  // .fields.numberOfPositionsOpen
  // .fields.positionName
  // .fields.roleDescription
  // .fields.roleRequirements

  for(var i = 0; i < postings.length; i++){

//orginal tab items change
    document.getElementById("positionsSliderTitles1").innerHTML = '<h2 class="position name tab">'+ postings[0].fields.positionName +'</h2>'


    document.getElementById('positionsSliderTabs1').innerHTML = '<div class="position-top-div"><div class="position-title-div"><h2 class="position name">'+ postings[0].fields.positionName +'</h2><h5 class="top-label blue">'+ postings[0].fields.numberOfPositionsOpen +'</h5></div><div class="w-clearfix"><a href="'+ postings[0].fields.applicationFormLink +'" target="_blank" class="button dark round apply w-button">Apply here</a></div></div><p class="paragraph small">'+ postings[0].fields.roleDescription +'</p><h5 class="top-label">Has-To-Have</h5><div class="paragraph small list">'+ postings[0].fields.roleRequirements +'</div>'

    if (postings.length > 1){

    document.getElementById("positionsSliderTitles2").innerHTML = '<h2 class="position name tab">'+ postings[1].fields.positionName +'</h2>'


    document.getElementById('positionsSliderTabs2').innerHTML = '<div class="position-top-div"><div class="position-title-div"><h2 class="position name">'+ postings[1].fields.positionName +'</h2><h5 class="top-label blue">'+ postings[1].fields.numberOfPositionsOpen +'</h5></div><div class="w-clearfix"><a href="'+ postings[1].fields.applicationFormLink +'" target="_blank" class="button dark round apply w-button">Apply here</a></div></div><p class="paragraph small">'+ postings[1].fields.roleDescription +'</p><h5 class="top-label">Has-To-Have</h5><div class="paragraph small list">'+ postings[1].fields.roleRequirements +'</div>'



    if (i > 1){
        if (postings[i].fields.positionName  != undefined || postings[i].fields.positionName != null){

          var num = i+1;

      tabTitles += '<a  data-w-tab="Tab '+ num +'" class="positions-tabs w-inline-block w-tab-link"><h2 class="position name tab">'+ postings[i].fields.positionName +'</h2></a>'


      tabContent += '<div data-w-tab="Tab '+ num +'" class="w-tab-pane"><div class="descriptions-div"><div class="position-top-div"><div class="position-title-div"><h2 class="position name">'+ postings[i].fields.positionName +'</h2><h5 class="top-label blue">'+ postings[i].fields.numberOfPositionsOpen +'</h5></div><div class="w-clearfix"><a href="'+ postings[i].fields.applicationFormLink +'" target="_blank" class="button dark round apply w-button">Apply here</a></div></div><p class="paragraph small">'+ postings[i].fields.roleDescription +'</p><h5 class="top-label">Has-To-Have</h5><div class="paragraph small list">'+ postings[i].fields.roleRequirements +'</div></div></div>'

        }
      }
    }
  }

    document.getElementById('positionsSliderTitles').insertAdjacentHTML('beforeend', tabTitles )

    document.getElementById('positionsSliderTabs').insertAdjacentHTML('beforeend', tabContent )
}
